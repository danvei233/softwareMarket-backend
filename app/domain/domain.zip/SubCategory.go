package domain

import (
	"context"
)

type SubCategory struct {
	ID       uint64       `gorm:"primaryKey;autoIncrement"`
	Name     string       `gorm:"type:varchar(255);not null"`
	Icon     string       `gorm:"type:varchar(255)"`
	ParentID uint64       `gorm:"not null;index"`
	Parent   MainCategory `gorm:"foreignKey:ParentID;references:ID;constraint:OnUpdate:CASCADE,OnDelete:SET NULL"`
}

// SubCategoryRepository defines operations on SubCategory.
type SubCategoryRepository interface {
	Update(ctx context.Context, o *SubCategory) error
	Del(ctx context.Context, id uint64) error
	GetList(ctx context.Context) ([]*SubCategory, error)
	GetSoftwareList(ctx context.Context, subCategoryID uint64) ([]*Software, error)
	Add(ctx context.Context, o *SubCategory) (uint64, error)
	AddSoftware(ctx context.Context, subCategoryID uint64, softwareID uint64) error
}
